pkgs.required <- function(){
pkgs.online <- sort(c("rhandsontable", "shiny", "jsonlite", "XLConnect", 
                      "shinyBS", "uuid", "mailR", "rmarkdown", "installr"))
return(list(pkgs.online))
}